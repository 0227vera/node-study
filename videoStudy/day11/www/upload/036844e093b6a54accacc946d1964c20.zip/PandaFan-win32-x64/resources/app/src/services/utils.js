const nodejsTcpPing = require('nodejs-tcp-ping');
const fetch = require('node-fetch');
var http = require('http');
var ProxyAgent = require('proxy-agent');
let Store = require('electron-store')
let store = new Store()

let siteMeta = null;

exports.toType = (obj) => {
  return ({}).toString.call(obj).match(/\s([a-zA-Z]+)/)[1].toLowerCase()
}

exports.tcpPing = (server, port, opt) => {
  return nodejsTcpPing.tcpPing({
    attempts: opt.attempts || 3,
    host: server,
    port: port,
    timeout: opt.timeout || 5000
  })
}

exports.getSiteMeta = async (refresh) => {
  if (siteMeta && !refresh)
    return Promise.resolve(siteMeta)
  let opt = {}
  let localProxy = store.get('localProxy', {})
  if (localProxy.enable) {
    opt = {
      agent: new ProxyAgent(`${localProxy.type}://${localProxy.host}:${localProxy.port}`)
    }
  }
  return fetch("https://myfiles.b0.upaiyun.com/panda/sitemeta.json", opt)
  .then(res => res.text())
  .then((data) => {
    data = JSON.parse((new Buffer(data, 'base64')).toString().trim())
    siteMeta = data
    return Promise.resolve(data);
  });
}