let fetch = require('node-fetch');
let store = new (require('electron-store'))();
let ProxyAgent = require('./proxyagent');
let NetworkSettings = require('./networksettings');
let URLSearchParams = require('url').URLSearchParams;
const appVersion = require('electron').app.getVersion();
const Sentry = require('@sentry/node');
Sentry.init({ dsn: 'https://2e071fe1b3154c509bbf4cee6ca5e291@sentry.io/1300574' });

let APPSTATE = {};

let proxyApp = null;
let networkSetter = null;

let localCache = {};

const isDevMode = process.execPath.match(/[\\/]electron/);

let api_url = "";

let set_proxy = true;


class PandaAPI {
    constructor (credentials) {
        this.store = store;
        this.appVersion = appVersion;
        this.api_url = api_url || 'https://xiongmao.io/api/';
        this.current_proxy_config = {}
        let user = store.get('user');
        if (user) {
            this.jwt_token = user.jwt_token;
            this.user = user;
        } else if (credentials) {
            this.credentials = credentials;
            if (credentials.jwt_token) {
                this.jwt_token = credentials.jwt_token;
            } else {
                this.email = credentials.email;
                this.password = credentials.password;
            }
        }
        return this;
    }
    fetch () {
        return fetch.apply(null, arguments)
            .then(res => res.text())
            .then((text)=>{
                console.log(text);
                return Promise.resolve(JSON.parse(text));
            })
    }
    setApiURL (d) {
        api_url = d;
        this.api_url = d;
    }
    async post (url, body) {
        let headers = {
            'Content-Type': 'application/json',
            'x-panda-app': `APP-${process.platform}-${appVersion}`
        };
        let _url = url;
        if (!url.startsWith('http'))
            _url = this.api_url + _url;
        if (this.jwt_token)
            headers['x-panda-authorization'] = this.jwt_token;
        let param = {
            method: 'POST',
            body: JSON.stringify(body),
            headers
        };
        return this.fetch(_url, param);
    }
    async get (url, query) {
        let updateCahce = false;
        if (query) {
            updateCahce = query['$updateCache'];
            delete(query['$updateCache'])
        }
        let headers = {
            'Content-Type': 'application/json',
            'x-panda-app': `APP-${process.platform}-${appVersion}`
        };
        let _url = url;
        if (!url.startsWith('http'))
            _url = this.api_url + _url;
        if (this.jwt_token)
            headers['x-panda-authorization'] = this.jwt_token;
        if (query)
            _url += `?${new URLSearchParams(query)}`;
        let param = {
            method: 'GET',
            headers
        };
        if (!updateCahce && localCache[_url])
            return Promise.resolve(localCache[_url]);

        console.log('fetching (no cache)...');

        return this.fetch(_url, param)
        .then((data) => {
            localCache[_url] = data;
            return Promise.resolve(data);
        });
    }
    async auth () {
        if (this.user || this.jwt_token)
            return Promise.resolve(this.user)
        return this.post('sessions', this.credentials);
    }
    signOut () {
        store.clear();
        localCache = {};
        return true;
    }
    setState (key, val) {
        APPSTATE[key] = val;
        return true;
    }
    getState (key) {
        if (key)
            return APPSTATE[key];
        return APPSTATE;
    }
    delState (key) {
        delete(APPSTATE[key]);
        return true;
    }
    clearState () {
        APPSTATE = {};
        return true;
    }
    getProxyServer (service, line, config) {
        proxyApp = new ProxyAgent(service, line, config);
        return proxyApp;
    }
    getnetworkSetter (proxy_port) {
        networkSetter = new NetworkSettings(proxy_port);
        return networkSetter;
    }
    async startService () {
        console.log(0);

        let allData = store.store
        
        
        let line = allData.runTimeState.selected_line

        console.log(line);
        

        if (allData.runTimeState.workmode == 'auto')
            line = allData[allData.runTimeState.current_service_cate + '_lines']
        
        let config = {
            port: Number(allData.runTimeState.port) || 10080,
            servermode: allData.runTimeState.servermode,
            global: !allData.runTimeState.smart_route,
            strategy: allData.runTimeState.strategy || 'lha',
            checkwebsite: allData.runTimeState.checkwebsite || 'www.apple.com',
            checkduration: Number(allData.runTimeState.checkduration) || 30,
            set_proxy: allData.runTimeState.set_proxy
        }

        set_proxy = allData.runTimeState.set_proxy == 'auto'
        
        let service = allData.service[allData.runTimeState.current_service_cate]

        
        console.log(service, line, config);
        
        console.log(1);
        
        await this.stopService(config);
        console.log(2);
        
        let proxy = this.getProxyServer(service, line, config);
        console.log(3);
        
        await proxy.updateConfig();
        console.log(4);
        
        try {
            await proxy.start();
        } catch (e) {
            Sentry.captureException(e)
        }
        console.log(5);

        this.current_proxy_config = config;
        
        if (set_proxy) {
            let setter = this.getnetworkSetter(config.port);
            try {
                await setter.enableProxy();
            } catch (e) {
                Sentry.captureException(e)
                console.log(e);
                await proxy.stop();
                throw e;
            }
        }

        require('../tray-manager').setIcon('icon_connected_16x16')

        return proxyApp;
    }
    async stopService () {
        console.log('stopping service');
        let allData = store.store

        if (set_proxy) {
            console.log('disabling proxy settings...');
            if (!networkSetter)
                networkSetter = new NetworkSettings(this.current_proxy_config.proxy_port);
            await networkSetter.disableProxy();
        }
        if (proxyApp)
            await proxyApp.stop();
        console.log('service stopped');

        if (allData.runTimeState) {
            allData.runTimeState.connect_state = {
                line: {}
            }
            store.set('runTimeState', allData.runTimeState)
        }
        require('../tray-manager').setIcon('icon_16x16')
        console.log('all stopped.');
        return true;
    }
    async updateApp () {
        console.log(__dirname);
        // TODO
    }
}


module.exports = PandaAPI;