const { spawn }     = require('child_process');
const { promisify } = require('util');
const fs            = require('fs');
const readFile      = promisify(fs.readFile);
const writeFile     = promisify(fs.writeFile);
const utils         = require('./utils');
const path          = require('path');
let Store = require('electron-store')
let store = new Store()

let currentProcess = null;

// config: {
//      port: 10080,
//      server_mode: ''
//      global: bool
// }

let isSSR = function (extra) {
    if (extra.ss_proto !== 'origin')
        return true;
    if (extra.ss_obfs !== 'plain')
        return true;
    return false;
}

class ProxyAgent {
    constructor (service, lines, config) {
        console.log('got lines:', lines);

        this.service = service;
        this.lines = lines;
        if (utils.toType(lines) == 'object')
            this.lines = [lines];
        this.config = config;
        this.excutable = path.resolve(__dirname, `../bin/${process.platform}/glider`);
        if (process.platform == 'win32') {
            this.excutable = path.resolve(__dirname, `../bin/${process.platform}/${process.arch}/glider.exe`);
        }
        this.config_presets = path.resolve(__dirname, '../conf');
        this.configfile = path.resolve(this.config_presets, 'glider.conf');
        this.presets = path.resolve(this.config_presets, `${this.service.cate}_rules.d`);
        return this;
    }
    genForwarder (line, mode) {
        console.log('gen->', line, mode);

        
        let proxy_server;
        switch (mode) {
            case 'ssltide':
                let pwd;
                if (this.service.cate == 'home')
                    pwd = this.service.extra.ocpwd;
                else
                    pwd = this.service.extra.sslpwd || this.service.extra.pac_name;
                proxy_server = `tls://${line.server}:${line.ssltide_port || 3389},http://${this.service.user_id}:${pwd}@`;
                break;
            case 'ss':
                let arr = line.server.split('.');
                arr[0] += '-ss';
                let s = arr.join('.');
                if (isSSR(this.service.extra))
                    proxy_server = `ssr://${this.service.extra.ss_method}:${this.service.extra.sspwd || this.service.extra.pac_name}@${s}:${this.service.extra.ss_port}?protocol=${this.service.extra.ss_proto}&protocol_param=${this.service.extra.ss_proto_param}&obfs=${this.service.extra.ss_obfs}&obfs_param=${this.service.extra.ss_obfs_param}`;
                else
                    proxy_server = `ss://${this.service.extra.ss_method}:${this.service.extra.sspwd || this.service.extra.pac_name}@${s}:${this.service.extra.ss_port}`;
                break;
            case 'v2':
                proxy_server = `vmess://aes-128-gcm:${this.service.extra.v2_id}@${line.v2_host || line.server}:${line.v2_port}?alterID=${this.service.extra.v2_alter_id || 2}`;
                break;
            default:
                break;
        }
        let ret = `forward=${proxy_server}`;

        let localProxy = store.get('localProxy', {})
        if (localProxy.enable) {
            let localProxyStr = `${localProxy.type}://${localProxy.host}:${localProxy.port}`
            ret = `forward=${localProxyStr},${proxy_server}`;
        }
        
        console.log(ret);
        return(ret);
    }
    async updateConfig () {

        console.log(this.config);
        
        let conf_arr = [
            `listen=:${this.config.port || 10080}`,
            `listen=:${(this.config.port || 10080) + 1}`
        ];
        let proxy_file = this.presets + '/proxy.rule';

        let proxy_arr = [];
        let proxy_server;
        for (let line of this.lines) {
            console.log('configing this line:', line);
            
            if (this.config.servermode == 'auto' || this.lines > 1){
                for (const mode of ['ssltide', 'ss', 'v2']) {
                    console.log('mm-->>', line[mode]);
                    if (line[mode])
                        proxy_arr.push(this.genForwarder(line, mode));
                }
            } else {
                proxy_arr.push(this.genForwarder(line, this.config.servermode));
            }
        }

        if (this.config.servermode == 'auto' || this.lines > 1) {
            proxy_arr = proxy_arr.concat([
                `strategy=${this.config.strategy || 'lha'}`,
                `checkwebsite=${this.config.checkwebsite || 'www.apple.com'}`,
                `checkduration=${this.config.checkduration || 30}`
            ]);
        }

        console.log(this.service.extra);

        if (this.config.global) {
            conf_arr = conf_arr.concat(proxy_arr);
        } else {
            conf_arr.push(`rules-dir=${this.service.cate}_rules.d`);
            proxy_arr.push(`include=proxy.list`);
            proxy_arr.push(`include=user_proxy.list`);
            await this.writeUserProxyLists();
            await writeFile(proxy_file, proxy_arr.join('\n'));
        }

        return await this.writeConfigFile(conf_arr.join('\n'));
    }
    async writeUserProxyLists () {
        const rulelist = {
            include: path.resolve(this.presets, 'user_proxy.list'),
            exclude: path.resolve(this.presets, 'user_bypass.list')
        }
        for (let [key, value] of Object.entries(rulelist)) {
            let content = [];
            if (this.service.extra[key].length) {
                let domain_list = this.service.extra[key];
                let arr = domain_list.replace(/\s+/g, '').split(',');
                for (let d of arr) {
                    if (d.length) {
                        content.push(`domain=${d}`);
                    }
                }
            }
            await writeFile(value, content.join('\n'));
        }
        return;
    }
    async readConfigFile () {
        return (await readFile(this.configfile)).toString();
    }
    async writeConfigFile (content) {
        return await writeFile(this.configfile, content);
    }
    async start () {
        this.stop();
        currentProcess = spawn(this.excutable, ['-config', this.configfile, '-verbose']);

        currentProcess.stdout.on('data', (d) => {
            d = d.toString();
            if (this.stdout)
                this.stdout(d);
            console.log(d);
            
        });
        currentProcess.stderr.on('data', (d) => {
            d = d.toString();
            if (this.stderr)
                this.stderr(d);
            console.log(d);
        });
        return currentProcess;
    }
    stop () {
        if (!currentProcess)
            return true;
        currentProcess.kill();
        currentProcess = null;
        return true;
    }
    running () {
        return currentProcess ? true : false;
    }
}

module.exports = ProxyAgent;