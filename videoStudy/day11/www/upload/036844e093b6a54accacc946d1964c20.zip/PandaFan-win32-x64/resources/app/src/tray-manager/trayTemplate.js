import { app, shell, BrowserWindow, Menu, Tray, nativeImage, screen, globalShortcut, dialog, session } from 'electron';
// import { disconnect } from 'cluster';
let path = require('path')
let Panda = new (require('../services/panda'))();
let store = new (require('electron-store'))();
let mainWindowManager = require('../windows/mainWindow')
let logWindowManager = require('../windows/logWindow')
let settingsWindowManager = require('../windows/settingsWindow')
let PandaFanAutoLauncher = require('./autoLauncher')

let ServerMenuItem = () => {
    let clickHandler = async (menuitem) => {
        console.log(menuitem.label);
        let state = store.get('runTimeState', {})
        let lines = store.get(state.current_service_cate + '_lines', [])
        let selected_line = lines.find(l => l.name == menuitem.label)

        state.selected_line = selected_line
        store.set('runTimeState', state)
        // disconnect
        // connect
        // suc? - reset check mark. update runtimestate.
        // mainwindow open? - refresh the page...
        try {
            await Panda.stopService()
            await Panda.startService()

            let servermode = state.servermode
            if (!selected_line[servermode])
                servermode = 'auto'

            let connect_state = {
                line: JSON.parse(JSON.stringify(selected_line)),
                servermode: state.servermode,
                status: 'connected'
            };

            state.connect_state = connect_state
            state.servermode    = servermode

            store.set('runTimeState', state)

            menuitem.checked = true

            if (mainWindowManager.getWindow())
                mainWindowManager.getWindow().reload()
        } catch (e){
            console.log(e);
            return dialog.showErrorBox('Error', '线路连接失败，查看日志获取错误信息')
        }
    }
    
    let serverList = []

    let state = store.get('runTimeState', {})

    if (state.current_service_cate) {
        let lines = store.get(state.current_service_cate + '_lines', [])

        for (const line of lines) {
            serverList.push({
                label: line.name,
                checked: state.connect_state.line.name == line.name,
                type: 'radio',
                click: clickHandler
            })
        }
    }
    
    return {
        label: 'Server',
        submenu: serverList
    }
}

let disconnect = async () => {
    try {
        await Panda.stopService()
    } catch (e) {}
    let connect_state = {
        line: {},
        servermode: store.get('runTimeState.servermode'),
        status: 'disconnected'
    };
    store.set('runTimeState.connect_state', connect_state)
}

let autoLaunchMenuItem = {
    label: 'Launch on Startup',
    type: 'checkbox',
    checked: false,
    click: (menuitem) => {
        PandaFanAutoLauncher.isEnabled()
        .then(function (isEnabled) {
            menuitem.checked = !isEnabled;
            autoLaunchMenuItem.checked = !isEnabled;
            if (isEnabled) {
                return PandaFanAutoLauncher.disable();
            } else {
                return PandaFanAutoLauncher.enable();
            }
        })
        .catch(function (err) {
            // handle error
            console.log('auto launch toggle failed:', err);
        });
    }
}



exports.generate = () => {
    let template = [
        ServerMenuItem(),
        {
            label: 'Disconnect',
            accelerator: 'CmdOrCtrl+X',
            click: disconnect
        },
        { type: 'separator' },
        {
            label: 'Show Dashboard',
            accelerator: 'CmdOrCtrl+D',
            click: async function () {
                mainWindowManager.open()
            }
        },
        {
            label: 'Show Logs',
            accelerator: 'CmdOrCtrl+L',
            click: async function () {
                logWindowManager.open()
            }
        },
        {
            label: 'Local Proxy Settings',
            click: async function () {
                settingsWindowManager.open()
            }
        },
        { type: 'separator' },
        autoLaunchMenuItem,
        { type: 'separator' },
        {
            label: 'Help',
            role: 'help',
            submenu: [
                {
                    label: `Go to PandaFan's Website`,
                    click: () => {
                        let PandaURL = store.get('siteURL', null)
                        if (!PandaURL)
                            PandaURL = 'https://XiongMao.io'
                        shell.openExternal(PandaURL);
                    }
                },
            ]
        },
        {
            label: 'Log out and Reset',
            click: async function () {
                Promise.all([
                    Panda.stopService(),
                    mainWindowManager.clearCache()
                ]).then(() => {
                    store.clear()
                    mainWindowManager.close()
                    mainWindowManager.open()
                })
            }
        },
        {
            label: 'Quit',
            accelerator: 'CmdOrCtrl+Q',
            click: async function () {
                await Panda.stopService();
                app.quit();
            }
        },
    ]

    return template
}