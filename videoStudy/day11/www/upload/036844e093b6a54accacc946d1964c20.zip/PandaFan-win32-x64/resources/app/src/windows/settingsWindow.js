import { app, BrowserWindow, Menu, Tray, nativeImage, screen, globalShortcut, dialog, session } from 'electron';
let path = require('path')
import { getSiteMeta } from '../services/utils'
let WindowManager = require('./windowManager')
let store = new (require('electron-store'))();

let settingsWindow = {};

// open mainWindow or show the existing window
exports.open = () => {
    if (settingsWindow.window) {
        settingsWindow.toggle()
        return settingsWindow
    }

    let opt = {
        vue: false,
        url: `file://${path.resolve(__dirname, '../settings.html')}`
    }

    settingsWindow = new WindowManager(opt)
    settingsWindow.toggle()
    return settingsWindow.window
}

exports.close = () => {
    settingsWindow.window.close()
}


exports.getWindow = () => {
    return settingsWindow.window
}