Error.stackTraceLimit = 100;

const Sentry = require('@sentry/node');
Sentry.init({
  dsn: 'https://2e071fe1b3154c509bbf4cee6ca5e291@sentry.io/1300574',
  release: require('electron').app.getVersion(),
  ignoreErrors: [
    "vbscript process reported unknown error code",
    "EPERM: operation not permitted, rename",
    "ENOTCONN",
    "Command failed",
    "ENOSPC",
    "EPERM",
    "ENOENT",
    "Can't install proxy helper"
  ]
});

let old_log = console.log

process.on("uncaughtException", (err) => {
  console.log('!!uncaughtException!!!')
  Sentry.captureException(err)
})

process.on('unhandledRejection', (reason, p) => {
  console.log('!!unhandledRejection!!!')
  console.log(reason, p);
  Sentry.captureException(reason)
})

// let logHistory = [];
console.log = (...args) => {
  old_log.apply(console, args);
  // logHistory.push(args);
  if (logWindowManager && logWindowManager.getWindow()) {
    logWindowManager.getWindow().webContents.send('new-log', args);
  }
}

import { app, BrowserWindow, Menu, Tray, nativeImage, screen, globalShortcut, dialog, session } from 'electron';

let store = new (require('electron-store'))();
var ipc = require('electron').ipcMain;

let PandaAPI = require('./services/panda');
let Panda = new PandaAPI();
const path = require('path');
let fetch = require('node-fetch');

require('./ipcHandler');
let mainWindowManager = require('./windows/mainWindow')
let logWindowManager  = require('./windows/logWindow')

let trayManager = require('./tray-manager')

console.log(2);

// Keep a global reference of the window object, if you don't, the window will
// be closed automatically when the JavaScript object is garbage collected.
const isDevMode = process.execPath.match(/[\\/]electron/);

if (!isDevMode) {
  if (process.platform == 'darwin') {
    if (!__dirname.startsWith('/Applications/')) {
      dialog.showErrorBox('不可以从这里运行哦！', `请先将 PandaFan.app 放入 Applications 文件夹中，\n然后从 Applications 文件夹中运行本程序\n\n请勿直接运行 DMG 文件中的副本`);
      process.exit();
    }
  }
}

// This method will be called when Electron has finished
// initialization and is ready to create browser windows.
// Some APIs can only be used after this event occurs.
app.on('ready', async () => {
  await Panda.stopService()
  mainWindowManager.open()
  trayManager.createTray();
});

// Quit when all windows are closed.
app.on('window-all-closed', () => {
  // On OS X it is common for applications and their menu bar
  // to stay active until the user quits explicitly with Cmd + Q
  if (process.platform == 'darwin')
    app.dock.hide();
});

app.on('before-quit', async () => {
  await Panda.stopService();
});

app.on('activate', () => {
  // On OS X it's common to re-create a window in the app when the
  // dock icon is clicked and there are no other windows open.
  mainWindowManager.open()
});

// In this file you can include the rest of your app's specific main process
// code. You can also put them in separate files and import them here.
