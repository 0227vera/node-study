let store = new (require('electron-store'))();

exports.start = (keys, func) => {
    let k;
    if (!Array.isArray(keys))
        k = [keys]
    else
        k = keys
    for (const kk of k) {
        store.onDidChange('home_lines', func)
    }
}