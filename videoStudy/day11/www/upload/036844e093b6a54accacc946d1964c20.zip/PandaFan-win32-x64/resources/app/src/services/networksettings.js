const { runCommand, runSudoCommand } = require('./commander');
const { promisify }                  = require('util');
const fs                             = require('fs');
const fstat                          = promisify(fs.fstat);
const open                           = promisify(fs.open);
const path                           = require('path');

let regedit;

if (process.platform == 'win32') 
    regedit = require('regedit');

const flatten = list => list.reduce(
    (a, b) => a.concat(Array.isArray(b) ? flatten(b) : b), []
)

const ProxyConf = `/Library/Application Support/PandaFan/ProxyConfig`;


// HTTP PROXY = HTTPS PROXY
// SOCKS5 PROXY WILL ALWAYS BE (HTTP PROXY + 1)
class NetworkSettings {
    constructor (http_proxy_port) {
        this.http_proxy_port = http_proxy_port;
        return this;
    }
    async enableProxy () {
        return this[`${process.platform}EnableProxy`]();
    }
    async disableProxy () {
        return this[`${process.platform}DisableProxy`]();
    }
    async setRegD (valuesToPut) {
        return new Promise((resolve, reject)=>{
            regedit.putValue(valuesToPut, function (err) {
                if (err) {
                    console.log(err);
                    return reject(err);
                }
                return resolve();
            });
        })
    }
    async win32DisableProxy () {
        var valuesToPut = {
            'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings': {
                'ProxyEnable': {
                    value: 0,
                    type: 'REG_DWORD'
                }
            }
        }
        var valuesToPut1 = {
            'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings': {
                'AutoDetect': {
                    value: 0,
                    type: 'REG_DWORD'
                }
            }
        }
        var valuesToPut2 = {
            'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings': {
                'AutoConfigURL': {
                    value: '',
                    type: 'REG_SZ'
                }
            }
        }
        await this.setRegD(valuesToPut);
        await this.setRegD(valuesToPut1);
        await this.setRegD(valuesToPut2);
        return true;
    }
    async win32EnableProxy () {
        await this.win32DisableProxy();
        var valuesToPut_enable = {
            'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings': {
                'ProxyEnable': {
                    value: 1,
                    type: 'REG_DWORD'
                }
            }
        }
        var valuesToPut_set = {
            'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings': {
                'ProxyServer': {
                    value: `127.0.0.1:${this.http_proxy_port}`,
                    type: 'REG_SZ'
                }
            }
        }
        await this.setRegD(valuesToPut_set);
        await this.setRegD(valuesToPut_enable);
        return true;
    }
    async darwinDisableProxy () {
        await this.makeSureHasUserPermission();
        let ret = await runCommand(`"${ProxyConf}" ${this.http_proxy_port} disable`);
        if (ret.stderr.length) {
            throw ret;
        }
        return true;
    }
    async darwinEnableProxy () {
        await this.makeSureHasUserPermission();
        let cmd = `"${ProxyConf}" ${this.http_proxy_port} enable`;
        let ret = await runCommand(cmd);
        if (ret.stderr.length) {
            throw ret;
        }
        return true;
    }
    async makeSureHasUserPermission () {
        if (await this.checkHelperPermission()) {
            return true;
        } else {
            try {
                let install_result = await this.installHelper();
                return true;
            } catch (e) {
                console.log(e);
                throw `Can't install proxy helper`;
            }
        }
    }
    async installHelper () {
        console.log(`${path.resolve(__dirname, '../bin/darwin/installhelper.sh')}`);
        return runSudoCommand(`sudo sh ${path.resolve(__dirname, '../bin/darwin/installhelper.sh')}`);
    }
    async checkHelperPermission () {
        try {
            let fd = await open(ProxyConf, 'r');
            let result = await fstat(fd);
            return (result.uid == 0);
        } catch (e) {
            return false;
        }
    }
}

module.exports = NetworkSettings;