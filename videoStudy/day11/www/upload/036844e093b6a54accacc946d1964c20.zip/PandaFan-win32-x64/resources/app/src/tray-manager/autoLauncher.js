let path = require('path');
let AutoLaunch = require('auto-launch');

let appPath;
if (process.platform == 'darwin') {
    appPath = '/Applications/PandaFan.app';
} else {
    appPath = path.resolve(__dirname, '../../../../PandaFan.exe');
}

let PandaFanAutoLauncher = new AutoLaunch({
    name: 'PandaFan',
    path: appPath
});

module.exports = PandaFanAutoLauncher