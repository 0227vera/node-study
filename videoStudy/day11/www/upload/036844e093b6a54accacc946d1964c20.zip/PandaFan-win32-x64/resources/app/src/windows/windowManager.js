import { app, BrowserWindow, Menu, Tray, nativeImage, screen, globalShortcut, dialog, session } from 'electron';
import installExtension, { VUEJS_DEVTOOLS } from 'electron-devtools-installer';
let Store = require('electron-store')
let store = new Store()

let URL = require('url')
const path = require('path')

const isDevMode = process.execPath.match(/[\\/]electron/);

const eventHandlingDelay = 100

class WindowManager {
    constructor (opt) {
        this.opt = opt;
        this.stateChangeTimer = null;
        this.windowName = opt.name
    }

    async create () {
        const { width, height } = screen.getPrimaryDisplay().workAreaSize;
        // console.log('width:', width, 'height:', height);
        
        // let windowHeight = Math.min(height * 0.8, 750)
        // let windowWidth = windowHeight * 0.6

        // console.log('REAL: width:', windowWidth, 'height:', windowHeight);
        let self = this

        let last_state = store.get(`windowState:${this.windowName}`, {})

        this.window = new BrowserWindow({
            width: last_state.width || 430,
            height: last_state.height || 730,
            skipTaskbar: true,
            titleBarStyle: 'hidden',
            webPreferences: { webSecurity: false },
            resizable: true,
            icon: path.resolve(__dirname, '../assets/img/app_icon.icns')
        })

        this.window.setMenu(null)

        let localProxy = this.opt.localProxy || {}
        if (localProxy.enable) {
            let domainList = ['<local>', '192.168.0.0/16', '172.16.0.0/12', '10.0.0.0/8']
            // for (let [k, v] of siteMeta) {
            //     domainList.push(`.${(new URL(v)).hostname}`)
            // }
            // console.log(domainList);
            let proxy_str = `${localProxy.type}://${localProxy.host}:${localProxy.port},direct://`
            console.log(proxy_str);
            
            self.window.webContents.session.setProxy({
                proxyRules: proxy_str,
                proxyBypassRules: domainList.join(',')
            }, async () => {
                self.window.loadURL(self.opt.url)
                self.setHandlers()
            });
        } else {
            this.window.loadURL(this.opt.url)
            self.setHandlers()
        }


        const template = [
            {
                label: 'Window',
                role: 'window',
                submenu: [
                    { role: 'minimize' },
                    { role: 'close' }
                ]
            },
            {
                label: 'Edit',
                role: 'edit',
                submenu: [
                    {
                        label: 'Undo',
                        role: 'undo',
                    }, {
                        label: 'Redo',
                        role: 'redo',
                    }, {
                        type: 'separator',
                    }, {
                        label: 'Cut',
                        role: 'cut',
                    }, {
                        label: 'Copy',
                        role: 'copy',
                    }, {
                        label: 'Paste',
                        role: 'paste',
                    }, {
                        type: 'separator',
                    }, {
                        label: 'Select all',
                        role: 'selectall',
                    },
                ]
            }
        ]

        if (process.platform === 'darwin') {
            const menu = Menu.buildFromTemplate(template)
            Menu.setApplicationMenu(menu)
        }
    }

    async setHandlers () {
        let self = this
        if (isDevMode) {
            if (this.opt.vue)
                await installExtension(VUEJS_DEVTOOLS);
            this.window.webContents.openDevTools();
        }
        this.window.on('closed', () => {
            self.window = null
        })

        this.window.on('resize', this.onResize.bind(this))
    }

    onResize (evt) {
        let self = this
        clearTimeout(this.stateChangeTimer);
        this.stateChangeTimer = setTimeout(()=>{
            try {
                self.saveSize(evt.sender)
            } catch (e) {}
        }, eventHandlingDelay);
    }

    saveSize (window) {
        console.log('saving resize')
        let bonuds = window.getBounds()
        let state = store.get(`windowState:${this.windowName}`, {})
        state.width = bonuds.width
        state.height = bonuds.height
        store.set(`windowState:${this.windowName}`, state)
        console.log('window state updated:', state);
    }

    show () {
        if (process.platform == 'darwin')
            app.dock.show()
        if (!this.window)
            return this.toggle()
        if (!this.window.isFocused())
            this.window.focus()
    }

    async toggle () {
        if (!this.window) {
            await this.create()
            this.show()
        } else {
            this.show()
        }
    }

    async clearCache () {
        if (!this.window)
            return Promise.resolve()
        let self = this
        return new Promise((resolve, reject) => {
            self.window.webContents.session.clearCache(() => {
                resolve()
            })
        })
    }
}

module.exports = WindowManager