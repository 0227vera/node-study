import { app, BrowserWindow, Menu, Tray, nativeImage, screen, globalShortcut, dialog, session } from 'electron';
let path = require('path')
import { getSiteMeta } from '../services/utils'
let WindowManager = require('./windowManager')
let store = new (require('electron-store'))();

let logWindow = {};

// open mainWindow or show the existing window
exports.open = () => {
    if (logWindow.window) {
        logWindow.toggle()
        return logWindow
    }

    let opt = {
        vue: false,
        url: `file://${path.resolve(__dirname, '../log.html')}`,
        name: 'log'
    }

    logWindow = new WindowManager(opt)
    logWindow.toggle()
    return logWindow.window
}

exports.close = () => {
    logWindow.window.close()
}


exports.getWindow = () => {
    return logWindow.window
}

