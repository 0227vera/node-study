import { app, BrowserWindow, Menu, Tray, nativeImage, screen, globalShortcut, dialog, session } from 'electron';
let path = require('path');
// let ico = nativeImage.createFromPath(path.resolve(__dirname, '../assets/img/nc_icon.png'));
let ico = nativeImage.createFromPath(path.resolve(__dirname, '../assets/img/icon_16x16.png'));
let contextMenu = {};
let trayTemplate = require('./trayTemplate');
let PandaFanAutoLauncher = require('./autoLauncher');
let appIcon = null;
let store = new (require('electron-store'))();
let storeEvent = require('../storeEvent')
let mainWindowManager = require('../windows/mainWindow')

let currentTemplate;

exports.createTray = async () => {
    if (appIcon)
        return;
    appIcon = new Tray(ico);
    appIcon.setToolTip(`Thanks for using PandaFan's service :)`);

    currentTemplate = trayTemplate.generate()
    
    PandaFanAutoLauncher.isEnabled()
    .then(function (isEnabled) {
        for (let item of currentTemplate) {
            if (item.label == 'Launch on Startup'){
                item.checked = isEnabled
                break
            }
        }
        // trayTemplate[2].checked = isEnabled;
        contextMenu = Menu.buildFromTemplate(currentTemplate);
        appIcon.setContextMenu(contextMenu);
    })
    .catch(function (err) {
        // handle error
        console.log('auto launch toggle failed:', err);
    });

    appIcon.on('double-click', () => {
        mainWindowManager.open()
    });
}

exports.getCurrentMenu = () => {
    return {
        contextMenu,
        currentTemplate
    }
}

exports.setTitle = (text) => {
    if (appIcon)
        appIcon.setTitle(text)
}

exports.setIcon = (imgName) => {
    if (appIcon) {
        let newico = nativeImage.createFromPath(path.resolve(__dirname, `../assets/img/${imgName}.png`));
        appIcon.setImage(newico)
    }
}

exports.setMenu = (newTemplate) => {
    contextMenu = Menu.buildFromTemplate(newTemplate);
    if (appIcon)
        appIcon.setContextMenu(contextMenu);
}

exports.rebuildMenu = () => {
    console.log('rebuild menu...');
    contextMenu = Menu.buildFromTemplate(trayTemplate.generate());
    if (appIcon)
        appIcon.setContextMenu(contextMenu);
}

exports.updateServerCheckMark = (name, checkmark) => {
    // whatever, fuckit...
    return exports.rebuildMenu()

    // TODO.
    let state = store.get('runTimeState', {})
    let serverMenu = contextMenu.items.find(i => i.label == 'Server')
    
    for (let sub of serverMenu.submenu.items) {
        if (checkmark) {
            console.log(sub.label, ' - change to - ', sub.label == name);
            
            sub.checked = sub.label == name
        } else {
            console.log(sub.label, ' - set to false [ALL]');
            sub.checked = false
        }
    }
}