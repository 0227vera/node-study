const util = require('util');
const exec = util.promisify(require('child_process').exec);

exports.runCommand = async (command) => {
    let ret;
    try {
        ret = await exec(command, { encoding: 'utf8' });
    } catch (e) {
        ret = e;
    }
    return ret;
}

exports.runSudoCommand = async (command) => {
    let prompt = `/usr/bin/osascript -e 'do shell script "bash -c \\\"${command}\\\"" with administrator privileges'`;
    return exec(prompt)
}
