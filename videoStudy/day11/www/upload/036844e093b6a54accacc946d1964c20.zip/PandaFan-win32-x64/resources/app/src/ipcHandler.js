var ipc = require('electron').ipcMain;
var PandaAPI = require('./services/panda');
var utils = require('./services/utils');
let Panda = new PandaAPI();
let mainWindowManager = require('./windows/mainWindow');
let store = new (require('electron-store'))();
let TrayManager = require('./tray-manager')

ipc.on('reset', async (event) => {
    Promise.all([
        Panda.stopService(),
        mainWindowManager.clearCache()
    ]).then(() => {
        store.clear()
        mainWindowManager.reOpen()
    })
})

ipc.on('connect', async (event, arg) => {
    let ret;
    try {
        ret = await Panda.startService()
        console.log(ret);
    } catch (e) {
        console.log(e);
        ret = {
            failed: true,
            reason: e
        }
    }
    console.log(ret)
    try {
        event.sender.send('connect-reply', ret)
    } catch (e) {}

    if (!ret.failed) {
        let connect_state = {
            line: JSON.parse(JSON.stringify(store.get('runTimeState.selected_line'))),
            servermode: store.get('runTimeState.servermode'),
            status: 'connected'
        }
        store.set('runTimeState.connect_state', connect_state);
    }
})

ipc.on('disconnect', async (event, arg) => {
    let ret;

    try {
        ret = await Panda.stopService()
    } catch (e) {
        console.log(e);
        ret = {
            failed: true,
            reason: e
        }
    }
    console.log(ret)
    // disconnect/connect should make all the side affects(updateding connect status)
    // incase the dashboard was closed before send back response.
    try {
        event.sender.send('disconnect-reply', ret)
    } catch (e) {}
    let connect_state = {
        line: {},
        servermode: store.get('runTimeState.servermode'),
        status: 'disconnected'
    };
    store.set('runTimeState.connect_state', connect_state)
})

ipc.on('user-info-update', (event, arg) => {
    console.log(arg);
    TrayManager.rebuildMenu()
})

ipc.on('tcp-ping', async (event, arg) => {
    console.log(arg);
    let ret;
    try {
        ret = {
            result: await utils.tcpPing(arg.server, arg.port, arg.opt || {}),
            server: arg.server,
            port: arg.port,
            opt: arg.opt
        }
    } catch (e) {
        console.log(e);
        ret = {
            failed: true,
            reason: e
        }
    }
    console.log(ret)
    try {
        event.sender.send('tcp-ping-reply', ret)
    } catch (e) {}
})

ipc.on('require', (event, arg) => {
    console.log('gonna get module: ', arg);
    try {
        event.returnValue = require(arg)
    } catch (e) {}
})

ipc.on('system-info', (event, arg) => {
    try {
        event.returnValue = {
            platform: process.platform,
            arch: process.arch
        }
    } catch (e) { }
})