var http = require('http');
var fs   = require('fs');
var app  = require('remote').require('app')
let path = require('path');


class Downloader {
    constructor(url, filepath) {
        this.url = url;
        this.filepath = filepath;
    }
    async download () {
        // dl to temp file first.
        let tmp_file = fs.createWriteStream(path.resolve(__dirname, ''));
        let file = fs.createWriteStream(this.filepath);
        fetch(url)
        .then(res => {
            return new Promise((resolve, reject) => {
                res.body.pipe(file);
                res.body.on('error', err => {
                    reject(err);
                });
                file.on('finish', () => {
                    resolve();
                });
                file.on('error', err => {
                    reject(err);
                });
            });
        });
    }
}