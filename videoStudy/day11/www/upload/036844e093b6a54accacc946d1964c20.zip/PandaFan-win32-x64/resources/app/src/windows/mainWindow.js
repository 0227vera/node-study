import { app, BrowserWindow, Menu, Tray, nativeImage, screen, globalShortcut, dialog, session } from 'electron';
import { getSiteMeta } from '../services/utils'
let WindowManager = require('./windowManager')
let store = new (require('electron-store'))();
let URL = require('url')

let mainWindow = {};

const isDevMode = process.execPath.match(/[\\/]electron/);

// open mainWindow or show the existing window
exports.open = async () => {
    if (mainWindow.window) {
        mainWindow.toggle()
        return mainWindow
    }

    let siteMeta;

    try {
        siteMeta = await getSiteMeta()
        store.set('siteURL', siteMeta.siteURL)
        store.set('apiURL', siteMeta.apiURL)
    } catch (e) {
        console.log('getting siteMeta failed.', e);
        return dialog.showErrorBox('Error', '加载 API 信息失败，请稍后重启客户端重试。若持续出现此错误，请发送邮件至 panda@pandafan.org 咨询')
    }

    let opt = {
        vue: true,
        url: isDevMode ? `http://192.168.1.104:8000` : `${siteMeta.uiURL}`,
        localProxy: store.get('localProxy', {}),
        name: 'main'
    }

    mainWindow = new WindowManager(opt)
    mainWindow.toggle()
    return mainWindow.window
}

exports.close = () => {
    if (mainWindow.window)
        mainWindow.window.close()
}

exports.getWindow = () => {
    return mainWindow.window
}

exports.reOpen = () => {
    if (mainWindow.window)
        mainWindow.window.destroy()
    exports.open()
}

exports.clearCache = () => {
    if (mainWindow)
        return mainWindow.clearCache()
}